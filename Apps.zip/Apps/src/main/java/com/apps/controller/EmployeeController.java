package com.apps.controller;

import com.apps.model.Employee;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/apps")
public class EmployeeController {

  @GetMapping("/")
  public String getValues(){
    return "Hi Welcome to Peit";
  }

}
